package ssg.com.maeil.daoimpl;

import java.util.Date;
import java.util.List;


import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ssg.com.maeil.dao.CalendarDao;
import ssg.com.maeil.dto.CalendarDto;
import ssg.com.maeil.dto.CalendarParam;


@Repository
public class CalendarDaoImpl implements CalendarDao {

	@Autowired
	SqlSessionTemplate session;
	
	String ns = "Cal.";

	@Override 
	public List<CalendarDto> callist(CalendarParam param) { 
		System.out.println("CalendarDaoImpl callist()" + new Date());		
		return	session.selectList(ns + "calendarlist", param);
	}
	
	@Override
	public int calwrite(CalendarDto dto, String rdate) {
		System.out.println("CalendarDaoImpl calwrite()" + new Date());
		
		System.out.println("DaoImpl rdate = " + rdate);
		System.out.println("DaoImpl Dto = " + dto.toString());
				
		int count = session.insert(ns + "calwrite", dto);
		
		return count;
	}

	@Override
	public List<CalendarDto> getCalendarList(CalendarParam param, String yyyyMM) {	
		System.out.println("CalendarDaoImpl getCalendarList()" + new Date());
				
		System.out.println("DaoImpl=> getCalendarList" + param.toString() + "/" + yyyyMM);
		return session.selectList(ns + "getcalendarlist", yyyyMM);
	}

	@Override
	public CalendarDto caldetail(int seq) {
		System.out.println("CalendarDaoImpl caldetail()" + new Date());
		
		System.out.println("DaoImpl=> caldetail = " + seq);
		
		return session.selectOne(ns + "caldetail", seq);
	}

	@Override
	public List<CalendarDto> caldaylist(CalendarParam param) {
		System.out.println("CalendarDaoImpl getDayList()" + new Date());
		
		
		System.out.println("DaoImpl=> getDaylist = " + param);
		
		return session.selectList(ns + "caldaylist", param);
	}

	@Override
	public int calupdate(CalendarDto dto) {
		System.out.println("CalendarDaoImpl calupdate()" + new Date());
		int count = session.update(ns + "calupdateAf", dto)+1; 
		System.out.println("count 값은???" + count);
		return count;
	}

	@Override
	public int caldelete(CalendarParam param) {
		System.out.println("CalendarDaoImpl caldelete()" + new Date());
		int count = session.delete(ns + "caldelete", param);
		return count;
	}

	
	
	
}
